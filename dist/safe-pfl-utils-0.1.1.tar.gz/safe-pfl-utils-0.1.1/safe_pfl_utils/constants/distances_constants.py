DISTANCE_COORDINATE = "coordinate"
DISTANCE_COSINE = "cosine"
DISTANCE_EUCLIDEAN = "euclidean"
DISTANCE_WASSERSTEIN = "wasserstein"
