"""
safe-pfl-utils

SAFE-PFL utils
"""

__version__ = "0.1.1"
__author__ = "MohammadMojtaba Roshani"
__credits__ = "SAFE-PFL GitHub Organization "
